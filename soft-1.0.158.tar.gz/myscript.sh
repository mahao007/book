#! /bin/bash
service network restart
